from django.contrib import admin

# Register your models here.
from .models import Element

admin.site.register(Element)